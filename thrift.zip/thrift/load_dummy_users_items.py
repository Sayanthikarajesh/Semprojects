from datetime import datetime, timedelta
from django.contrib.auth.hashers import make_password
from catalog.models import User, Item

# Dummy user data
dummy_users = [
    {"username": "IndianaJones", "first_name": "Indiana", "email": "indy@adventures.com", "password": "indy@12345"},
    {"username": "JamesBond", "first_name": "James", "email": "bond@007.com", "password": "bond@12345"},
    {"username": "TonyStark", "first_name": "Tony", "email": "tony@starkindustries.com", "password": "tony@12345"},
    {"username": "LaraCroft", "first_name": "Lara", "email": "lara@croftadventures.com", "password": "lara@12345"},
    {"username": "HarryPotter", "first_name": "Harry", "email": "harry@hogwarts.com", "password": "harry@12345"},
]

# Populate the User table
for user_data in dummy_users:
    user_data["password"] = make_password(user_data["password"])  # Hash the password
    user = User.objects.create(**user_data)
    print(f"Created user: {user.username}")

# Dummy item data
dummy_items = [
    {
        "name": "Treasure Map",
        "description": "An old map leading to hidden treasures.",
        "price": 100.00,
        "category": "Antiques",
        "condition": "Used",
        "image": "images/treasure_map.jpg",
        "donated_by_username": "IndianaJones",
        "status": "Available",
        "added_date": datetime.now() - timedelta(days=3),
    },
    {
        "name": "Gold-Plated Cufflinks",
        "description": "Exclusive cufflinks for special occasions.",
        "price": 200.00,
        "category": "Accessories",
        "condition": "New",
        "image": "images/cufflinks.jpg",
        "donated_by_username": "JamesBond",
        "status": "Available",
        "added_date": datetime.now() - timedelta(days=2),
    },
    {
        "name": "Iron Man Helmet",
        "description": "Replica of the iconic Iron Man helmet.",
        "price": 500.00,
        "category": "Collectibles",
        "condition": "New",
        "image": "images/iron_man_helmet.jpg",
        "donated_by_username": "TonyStark",
        "status": "Available",
        "added_date": datetime.now() - timedelta(days=5),
    },
    {
        "name": "Ancient Artifact",
        "description": "A rare artifact from the Croft collection.",
        "price": 1000.00,
        "category": "Antiques",
        "condition": "Used",
        "image": "images/ancient_artifact.jpg",
        "donated_by_username": "LaraCroft",
        "status": "Available",
        "added_date": datetime.now() - timedelta(days=7),
    },
    {
        "name": "Magic Wand",
        "description": "A wand with a phoenix feather core.",
        "price": 300.00,
        "category": "Collectibles",
        "condition": "Used",
        "image": "images/magic_wand.jpg",
        "donated_by_username": "HarryPotter",
        "status": "Available",
        "added_date": datetime.now(),
    },
]

# Populate the Item table
for item_data in dummy_items:
    # Fetch the User instance based on the donated_by_username field
    donated_by_user = User.objects.filter(username=item_data.pop("donated_by_username")).first()
    if donated_by_user:
        item_data["donated_by"] = donated_by_user  # Set the donated_by foreign key
        Item.objects.create(**item_data)  # Create the Item object
        print(f"Added item: {item_data['name']} donated by {donated_by_user.username}")
    else:
        print(f"User {item_data['donated_by_username']} not found. Skipping item: {item_data['name']}")
