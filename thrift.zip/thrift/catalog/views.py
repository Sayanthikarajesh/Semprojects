from django.shortcuts import render,  get_object_or_404, redirect
from .models import Item, Order, Cart, Donation
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User

# Create your views here.
def home(request):
    return render(request, 'home.html')


def add_to_cart(request, item_id):
    item = get_object_or_404(Item, id=item_id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, item=item)
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    return redirect('cart')


def shop(request):
    # Fetch all available items
    items = Item.objects.filter(status="Available")
    return render(request, 'shop.html', {'items': items})

def donate(request):
    return render(request, 'home.html')

def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Successfully logged in!")
            return redirect('shop')  # Redirect to the shop page after login
        else:
            messages.error(request, "Invalid username or password. Please try again.")
    return render(request, 'login.html')

def register(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Check if passwords match
        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('register')

        # Check if username or email already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken. Please choose another.")
            return redirect('register')
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered.")
            return redirect('register')

        
        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user) 
        messages.success(request, "Registration successful!")
        return redirect('shop')  

    return render(request, 'register.html')

def donate(request):
    if request.method == "POST":
        
        name = request.POST.get('name')
        description = request.POST.get('description')
        price = request.POST.get('price')
        category = request.POST.get('category')
        condition = request.POST.get('condition')
        image = request.FILES.get('image')

        
        item = Item(
            name=name,
            description=description,
            price=price,
            category=category,
            condition=condition,
            image=image,
            donated_by=request.user  
        )
        item.save()

        
        # donation = Donation(
        #     user=request.user,  
        #     item=item  
        # )
        # donation.save()
        
        messages.success(request, "Your item has been successfully donated! Thankyou!")
        return redirect('donate')  

    return render(request, 'donate.html')



def profile(request):
    user = request.user
    donated_items = Donation.objects.filter(user=user)
    ordered_items = Order.objects.filter(user=user)
    cart_items = Cart.objects.filter(user=user)

    return render(request, 'profile.html', {
        'user': user,
        'donated_items': donated_items,
        'ordered_items': ordered_items,
        'cart_items': cart_items,
    })

def cart(request):
    if request.method == 'POST':
        cart_id = request.POST.get('cart_id')
        cart_item = Cart.objects.get(id=cart_id)

        if 'update_quantity' in request.POST:
            new_quantity = request.POST.get('quantity')
            if int(new_quantity) > 0:
                cart_item.quantity = int(new_quantity)
                cart_item.save()
                messages.success(request, f'Quantity of {cart_item.item.name} has been updated to {new_quantity}.')
            else:
                messages.error(request, 'Quantity must be a positive number.')
        
        elif 'remove_item' in request.POST:
            cart_item.delete()
            messages.success(request, f'{cart_item.item.name} has been removed from your cart.')

        return redirect('cart')  # Redirect back to the cart page to show the message
    
    # Your normal cart logic goes here (e.g., getting cart_items for the template)
    cart_items = Cart.objects.filter(user=request.user)
    return render(request, 'cart.html', {'cart_items': cart_items})

def logout_user(request):
    """
    Logs out the current user and redirects to the homepage or login page.
    """
    logout(request)
    return redirect('home') 
