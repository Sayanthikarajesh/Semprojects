from . import views
from django.urls import path

urlpatterns = [ 
    path('', views.home, name='home'),
    path('shop', views.shop, name='shop'),
    path('donate', views.donate, name='donate'),
    path('register', views.register, name='register'),
    path('login', views.user_login, name='login'),
    path('logout', views.logout_user, name='logout'),
    path('profile', views.profile, name='profile'),
    path('cart', views.cart, name='cart'),
    path('add-to-cart/<int:item_id>/', views.add_to_cart, name='add_to_cart'),
    path('checkout/<int:item_id>/', views.cart, name='checkout'),
    path('add-to-cart/<int:item_id>/', views.add_to_cart, name='add_to_cart'),

]
